import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
  type User,
} from 'firebase/auth';
import { doc, getDoc, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { auth, db, googleAuthProvider } from '../lib/firebase';
import { handleFirestoreError, OperationType } from '../lib/firestoreError';
import {
  BOOTSTRAPPED_ADMIN_EMAIL,
  type UserDoc,
  type UserProfileDoc,
} from '../types/domain';

interface RegisterPayload {
  fullName: string;
  email: string;
  mobileNumber: string;
  password: string;
  primaryVehicleReg?: string;
}

interface ProfileUpdatePayload {
  fullName: string;
  mobileNumber: string;
  primaryVehicleReg: string;
}

interface AuthContextValue {
  firebaseUser: User | null;
  userDoc: UserDoc | null;
  profileDoc: UserProfileDoc | null;
  isAdmin: boolean;
  loading: boolean;
  needsProfileCompletion: boolean;
  loginWithGoogle: () => Promise<void>;
  loginWithEmail: (email: string, password: string) => Promise<void>;
  registerWithEmail: (payload: RegisterPayload) => Promise<void>;
  sendPasswordReset: (email: string) => Promise<void>;
  saveProfile: (payload: ProfileUpdatePayload) => Promise<void>;
  logout: () => Promise<void>;
  getIdToken: () => Promise<string>;
  refreshUserState: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

function normalizePlate(raw?: string): string {
  return (raw || '').toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 20);
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [userDoc, setUserDoc] = useState<UserDoc | null>(null);
  const [profileDoc, setProfileDoc] = useState<UserProfileDoc | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  const loadUserRecords = useCallback(async (user: User) => {
    const isBootAdmin =
      user.email === BOOTSTRAPPED_ADMIN_EMAIL && user.emailVerified === true;

    let loadedUser: UserDoc | null = null;
    try {
      const userSnap = await getDoc(doc(db, 'users', user.uid));
      if (userSnap.exists()) {
        loadedUser = userSnap.data() as UserDoc;
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
    }

    let loadedProfile: UserProfileDoc | null = null;
    try {
      const profileSnap = await getDoc(doc(db, 'userProfiles', user.uid));
      if (profileSnap.exists()) {
        loadedProfile = profileSnap.data() as UserProfileDoc;
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, `userProfiles/${user.uid}`);
    }

    let adminDocActive = false;
    if (!isBootAdmin) {
      try {
        const adminSnap = await getDoc(doc(db, 'admins', user.uid));
        adminDocActive = adminSnap.exists() && adminSnap.data()?.active === true;
      } catch {
        adminDocActive = false;
      }
    }

    // Auto-bootstrap core user record for first-time Google Sign-In
    if (!loadedUser && user.displayName) {
      const safeName = user.displayName.trim().slice(0, 100) || 'Citizen User';
      const role = isBootAdmin ? 'admin' : 'citizen';
      try {
        await setDoc(doc(db, 'users', user.uid), {
          uid: user.uid,
          fullName: safeName,
          role,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        loadedUser = {
          uid: user.uid,
          fullName: safeName,
          role,
          createdAt: new Date(),
          updatedAt: new Date(),
        };
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, `users/${user.uid}`);
      }
    }

    setUserDoc(loadedUser);
    setProfileDoc(loadedProfile);
    setIsAdmin(isBootAdmin || adminDocActive || loadedUser?.role === 'admin');
  }, []);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      if (!user) {
        setUserDoc(null);
        setProfileDoc(null);
        setIsAdmin(false);
        setLoading(false);
        return;
      }

      try {
        await loadUserRecords(user);
      } catch (err) {
        console.error('Failed loading user records:', err);
      } finally {
        setLoading(false);
      }
    });

    return () => unsub();
  }, [loadUserRecords]);

  const refreshUserState = useCallback(async () => {
    if (firebaseUser) {
      await loadUserRecords(firebaseUser);
    }
  }, [firebaseUser, loadUserRecords]);

  const loginWithGoogle = useCallback(async () => {
    const result = await signInWithPopup(auth, googleAuthProvider);
    await loadUserRecords(result.user);
  }, [loadUserRecords]);

  const loginWithEmail = useCallback(
    async (email: string, password: string) => {
      try {
        const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
        await loadUserRecords(cred.user);
      } catch (err: unknown) {
        const code = (err as { code?: string })?.code;
        if (code === 'auth/operation-not-allowed') {
          throw new Error(
            'Email/Password sign-in is not yet enabled in the Firebase Console for this project. Please use Google Sign-In or enable Email/Password under Firebase Console > Authentication > Sign-in method.'
          );
        }
        throw err;
      }
    },
    [loadUserRecords]
  );

  const registerWithEmail = useCallback(
    async ({ fullName, email, mobileNumber, password, primaryVehicleReg }: RegisterPayload) => {
      const cleanName = fullName.trim().slice(0, 100);
      const cleanEmail = email.trim().slice(0, 160);
      const cleanMobile = mobileNumber.trim().slice(0, 20);
      const cleanPlate = normalizePlate(primaryVehicleReg);

      let cred;
      try {
        cred = await createUserWithEmailAndPassword(auth, cleanEmail, password);
      } catch (err: unknown) {
        const code = (err as { code?: string })?.code;
        if (code === 'auth/operation-not-allowed') {
          throw new Error(
            'Email/Password registration requires enabling the Email/Password provider in Firebase Console (Authentication > Sign-in method). You can also sign in immediately with Google.'
          );
        }
        throw err;
      }

      await updateProfile(cred.user, { displayName: cleanName });

      try {
        await setDoc(doc(db, 'users', cred.user.uid), {
          uid: cred.user.uid,
          fullName: cleanName,
          role: 'citizen',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        await setDoc(doc(db, 'userProfiles', cred.user.uid), {
          uid: cred.user.uid,
          fullName: cleanName,
          email: cleanEmail,
          mobileNumber: cleanMobile,
          primaryVehicleReg: cleanPlate,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        if (cleanPlate.length >= 4) {
          const vehicleId = `${cred.user.uid}_${cleanPlate}`;
          await setDoc(doc(db, 'registeredVehicles', vehicleId), {
            id: vehicleId,
            userId: cred.user.uid,
            registrationNumber: cleanPlate,
            vehicleType: 'Four-Wheeler',
            label: 'Primary Vehicle',
            ownershipVerified: false,
            verificationMethod: 'Pending Ownership Verification',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, `userProfiles/${cred.user.uid}`);
      }

      await loadUserRecords(cred.user);
    },
    [loadUserRecords]
  );

  const sendPasswordReset = useCallback(async (email: string) => {
    await sendPasswordResetEmail(auth, email.trim());
  }, []);

  const saveProfile = useCallback(
    async ({ fullName, mobileNumber, primaryVehicleReg }: ProfileUpdatePayload) => {
      if (!firebaseUser) throw new Error('Not authenticated.');
      const cleanName = fullName.trim().slice(0, 100);
      const cleanMobile = mobileNumber.trim().slice(0, 20);
      const cleanPlate = normalizePlate(primaryVehicleReg);
      const isBootAdmin =
        firebaseUser.email === BOOTSTRAPPED_ADMIN_EMAIL && firebaseUser.emailVerified;

      try {
        const userRef = doc(db, 'users', firebaseUser.uid);
        const userSnap = await getDoc(userRef);
        if (!userSnap.exists()) {
          await setDoc(userRef, {
            uid: firebaseUser.uid,
            fullName: cleanName,
            role: isBootAdmin ? 'admin' : 'citizen',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } else {
          await updateDoc(userRef, {
            fullName: cleanName,
            updatedAt: serverTimestamp(),
          });
        }

        const profileRef = doc(db, 'userProfiles', firebaseUser.uid);
        const profileSnap = await getDoc(profileRef);
        if (!profileSnap.exists()) {
          await setDoc(profileRef, {
            uid: firebaseUser.uid,
            fullName: cleanName,
            email: firebaseUser.email || '',
            mobileNumber: cleanMobile,
            primaryVehicleReg: cleanPlate,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } else {
          await updateDoc(profileRef, {
            fullName: cleanName,
            mobileNumber: cleanMobile,
            primaryVehicleReg: cleanPlate,
            updatedAt: serverTimestamp(),
          });
        }

        await loadUserRecords(firebaseUser);
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, `userProfiles/${firebaseUser.uid}`);
      }
    },
    [firebaseUser, loadUserRecords]
  );

  const logout = useCallback(async () => {
    await signOut(auth);
  }, []);

  const getIdToken = useCallback(async () => {
    if (!firebaseUser) throw new Error('User is not signed in.');
    return firebaseUser.getIdToken();
  }, [firebaseUser]);

  const needsProfileCompletion = Boolean(firebaseUser && !profileDoc && !loading);

  return (
    <AuthContext.Provider
      value={{
        firebaseUser,
        userDoc,
        profileDoc,
        isAdmin,
        loading,
        needsProfileCompletion,
        loginWithGoogle,
        loginWithEmail,
        registerWithEmail,
        sendPasswordReset,
        saveProfile,
        logout,
        getIdToken,
        refreshUserState,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}

export interface ChallanLookupRecord {
  challanNumber: string;
  vehicleRegNumber: string;
  violationCategory: string;
  incidentDate: string;
  locationText: string;
  amountInr: number;
  paymentStatus: 'Pending' | 'Paid' | 'Disputed';
  sourceName: string;
  isDemonstration: boolean;
}

export interface ChallanLookupResult {
  authorizedApiConnected: boolean;
  mode: 'authorized_api' | 'demonstration';
  providerNote: string;
  records: ChallanLookupRecord[];
}

export async function lookupVehicleChallans(
  plateNumber: string
): Promise<ChallanLookupResult> {
  const cleanPlate = plateNumber.toUpperCase().replace(/[^A-Z0-9-]/g, '');
  const apiKey = process.env.PARIVAHAN_ECHALLAN_API_KEY?.trim();
  const endpoint = process.env.PARIVAHAN_ECHALLAN_ENDPOINT?.trim();

  // Integration point for an officially authorized eChallan API
  if (apiKey && endpoint) {
    const url = new URL(endpoint);
    url.searchParams.set('vehicleNumber', cleanPlate);
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        Accept: 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`Authorized eChallan API returned HTTP ${response.status}.`);
    }

    const payload = (await response.json()) as { records?: ChallanLookupRecord[] };
    return {
      authorizedApiConnected: true,
      mode: 'authorized_api',
      providerNote: 'Live data retrieved from authorized eChallan integration endpoint.',
      records: Array.isArray(payload.records) ? payload.records : [],
    };
  }

  // Fallback: Clearly labelled demonstration records (never presented as official live govt data)
  const hash = cleanPlate
    .split('')
    .reduce((acc, ch) => acc + ch.charCodeAt(0), 0);

  const demoViolations: Array<{
    category: string;
    amount: number;
    status: 'Pending' | 'Paid' | 'Disputed';
    location: string;
    date: string;
  }> = [
    {
      category: 'Signal jumping',
      amount: 1000,
      status: 'Pending',
      location: 'SG Highway — Pakwan Junction (Demo)',
      date: '2026-09-14',
    },
    {
      category: 'Illegal parking',
      amount: 500,
      status: 'Paid',
      location: 'CG Road — Municipal Market Zone (Demo)',
      date: '2026-07-02',
    },
    {
      category: 'Over-speeding',
      amount: 2000,
      status: 'Pending',
      location: 'Ring Road — East Corridor Camera 04 (Demo)',
      date: '2026-10-19',
    },
  ];

  const primary = demoViolations[hash % demoViolations.length];
  const secondary = demoViolations[(hash + 1) % demoViolations.length];

  return {
    authorizedApiConnected: false,
    mode: 'demonstration',
    providerNote:
      'Authorized Parivahan / State eChallan API credentials (PARIVAHAN_ECHALLAN_API_KEY) are not configured. Displaying clearly labelled demonstration records after ownership verification.',
    records: [
      {
        challanNumber: `DEMO-CH-${cleanPlate.slice(-4)}-${100 + (hash % 899)}`,
        vehicleRegNumber: cleanPlate,
        violationCategory: primary.category,
        incidentDate: primary.date,
        locationText: primary.location,
        amountInr: primary.amount,
        paymentStatus: primary.status,
        sourceName: 'Demonstration eChallan Adapter (Unconnected)',
        isDemonstration: true,
      },
      {
        challanNumber: `DEMO-CH-${cleanPlate.slice(-4)}-${200 + ((hash * 3) % 799)}`,
        vehicleRegNumber: cleanPlate,
        violationCategory: secondary.category,
        incidentDate: secondary.date,
        locationText: secondary.location,
        amountInr: secondary.amount,
        paymentStatus: 'Paid',
        sourceName: 'Demonstration eChallan Adapter (Unconnected)',
        isDemonstration: true,
      },
    ],
  };
}

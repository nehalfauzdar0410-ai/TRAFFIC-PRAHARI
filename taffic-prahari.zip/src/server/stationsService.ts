export interface GeocodeResult {
  displayName: string;
  latitude: number;
  longitude: number;
}

export interface NearbyPoliceStation {
  id: string;
  name: string;
  address: string;
  phone: string | null;
  latitude: number;
  longitude: number;
  distanceKm: number;
  directionsUrl: string;
  isTrafficUnit: boolean;
  source: string;
}

const OSM_USER_AGENT = 'TrafficPrahariCivicPortal/1.0 (civic-road-safety-portal)';

function toRadians(deg: number): number {
  return (deg * Math.PI) / 180;
}

function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = toRadians(lat2 - lat1);
  const dLon = toRadians(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(lat1)) *
      Math.cos(toRadians(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 100) / 100;
}

export async function searchLocationsByQuery(query: string): Promise<GeocodeResult[]> {
  const url = new URL('https://nominatim.openstreetmap.org/search');
  url.searchParams.set('q', query);
  url.searchParams.set('format', 'jsonv2');
  url.searchParams.set('limit', '6');
  url.searchParams.set('addressdetails', '1');

  const response = await fetch(url.toString(), {
    headers: {
      'User-Agent': OSM_USER_AGENT,
      Accept: 'application/json',
    },
  });

  if (!response.ok) {
    throw new Error(`Location search provider returned HTTP ${response.status}.`);
  }

  const data = (await response.json()) as Array<{
    display_name: string;
    lat: string;
    lon: string;
  }>;

  return data.map((item) => ({
    displayName: item.display_name,
    latitude: Number(item.lat),
    longitude: Number(item.lon),
  }));
}

export async function reverseGeocodeCoordinates(
  lat: number,
  lon: number
): Promise<string> {
  const url = new URL('https://nominatim.openstreetmap.org/reverse');
  url.searchParams.set('lat', String(lat));
  url.searchParams.set('lon', String(lon));
  url.searchParams.set('format', 'jsonv2');

  const response = await fetch(url.toString(), {
    headers: {
      'User-Agent': OSM_USER_AGENT,
      Accept: 'application/json',
    },
  });

  if (!response.ok) {
    return `${lat.toFixed(5)}, ${lon.toFixed(5)}`;
  }

  const data = (await response.json()) as { display_name?: string };
  return data.display_name || `${lat.toFixed(5)}, ${lon.toFixed(5)}`;
}

async function queryOverpassPolice(
  lat: number,
  lng: number,
  radiusMeters: number
): Promise<NearbyPoliceStation[]> {
  const overpassQuery = `
    [out:json][timeout:12];
    (
      node["amenity"="police"](around:${radiusMeters},${lat},${lng});
      way["amenity"="police"](around:${radiusMeters},${lat},${lng});
    );
    out center tags;
  `;

  const response = await fetch('https://overpass-api.de/api/interpreter', {
    method: 'POST',
    headers: {
      'User-Agent': OSM_USER_AGENT,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: `data=${encodeURIComponent(overpassQuery)}`,
  });

  if (!response.ok) {
    throw new Error(`OpenStreetMap Overpass API returned HTTP ${response.status}.`);
  }

  const payload = (await response.json()) as {
    elements?: Array<{
      id: number;
      type: string;
      lat?: number;
      lon?: number;
      center?: { lat: number; lon: number };
      tags?: Record<string, string>;
    }>;
  };

  const elements = payload.elements || [];
  const results: NearbyPoliceStation[] = [];

  for (const el of elements) {
    const tags = el.tags || {};
    const stationLat = el.lat ?? el.center?.lat;
    const stationLng = el.lon ?? el.center?.lon;
    const name = tags.name || tags['name:en'];

    // Only include stations with real published coordinates and name in OSM
    if (stationLat === undefined || stationLng === undefined || !name) {
      continue;
    }

    const addressParts = [
      tags['addr:housenumber'],
      tags['addr:street'],
      tags['addr:suburb'] || tags['addr:neighbourhood'],
      tags['addr:city'] || tags['addr:town'],
      tags['addr:state'],
      tags['addr:postcode'],
    ].filter(Boolean);

    const address =
      tags['addr:full'] ||
      (addressParts.length > 0
        ? addressParts.join(', ')
        : `Coordinates: ${stationLat.toFixed(5)}, ${stationLng.toFixed(5)}`);

    const phone =
      tags.phone || tags['contact:phone'] || tags['phone:IN'] || null;

    const lowerName = name.toLowerCase();
    const isTrafficUnit =
      lowerName.includes('traffic') ||
      (tags.police || '').toLowerCase().includes('traffic');

    results.push({
      id: `${el.type}-${el.id}`,
      name,
      address,
      phone,
      latitude: stationLat,
      longitude: stationLng,
      distanceKm: haversineKm(lat, lng, stationLat, stationLng),
      directionsUrl: `https://www.google.com/maps/dir/?api=1&destination=${stationLat},${stationLng}`,
      isTrafficUnit,
      source: 'OpenStreetMap (Published Civic Data)',
    });
  }

  // Prioritize traffic units when within similar distance, otherwise sort by proximity
  results.sort((a, b) => a.distanceKm - b.distanceKm);
  return results;
}

export async function findNearbyTrafficPoliceStations(
  lat: number,
  lng: number
): Promise<{ stations: NearbyPoliceStation[]; searchRadiusKm: number }> {
  let stations = await queryOverpassPolice(lat, lng, 6000);
  let searchRadiusKm = 6;

  if (stations.length < 3) {
    stations = await queryOverpassPolice(lat, lng, 15000);
    searchRadiusKm = 15;
  }

  return {
    stations: stations.slice(0, 15),
    searchRadiusKm,
  };
}

import { GoogleGenAI, Type } from '@google/genai';

export interface OcrPlateResult {
  plateDetected: boolean;
  plateNumber: string;
  confidence: 'high' | 'medium' | 'low' | 'unreadable';
  qualityIssues: string;
  notes: string;
}

function normalizePlateText(raw: string): string {
  return raw
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '')
    .slice(0, 16);
}

export async function extractVehiclePlateFromImage(
  imageBase64: string,
  mimeType: string
): Promise<OcrPlateResult> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    throw new Error('OCR service is not configured: missing GEMINI_API_KEY on server.');
  }

  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  const prompt = [
    'Analyze this traffic photograph strictly for vehicle registration number plate OCR.',
    'Rules:',
    '1. Only report characters you can genuinely read on a vehicle license/number plate.',
    '2. If the image is blurry, dark, occluded, or no license plate is visible, set plateDetected to false (or confidence to "unreadable" / "low") and leave plateNumber empty if unreadable.',
    '3. Never guess or fabricate obscured characters. Never infer or output any vehicle owner personal information.',
    '4. Strip spaces and punctuation from plateNumber (e.g., "GJ01AB1234").',
    '5. Summarize image clarity/lighting issues honestly in qualityIssues and notes.',
  ].join('\n');

  const response = await ai.models.generateContent({
    model: 'gemini-4-hydrogen',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType,
            data: imageBase64,
          },
        },
        { text: prompt },
      ],
    },
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          plateDetected: {
            type: Type.BOOLEAN,
            description: 'Whether a vehicle registration plate is visible in the image.',
          },
          plateNumber: {
            type: Type.STRING,
            description: 'Normalized alphanumeric plate characters if readable, otherwise empty string.',
          },
          confidence: {
            type: Type.STRING,
            description: 'One of: high, medium, low, unreadable.',
          },
          qualityIssues: {
            type: Type.STRING,
            description: 'Detected blur, glare, low light, angle, or clear visibility.',
          },
          notes: {
            type: Type.STRING,
            description: 'Brief factual explanation of OCR extraction result for user confirmation.',
          },
        },
        required: ['plateDetected', 'plateNumber', 'confidence', 'qualityIssues', 'notes'],
      },
    },
  });

  const rawText = (response.text ?? '').trim();
  if (!rawText) {
    throw new Error('OCR model returned an empty response.');
  }

  const parsed = JSON.parse(rawText) as {
    plateDetected?: boolean;
    plateNumber?: string;
    confidence?: string;
    qualityIssues?: string;
    notes?: string;
  };

  const validConfidence = (['high', 'medium', 'low', 'unreadable'].includes(
    String(parsed.confidence)
  )
    ? parsed.confidence
    : 'unreadable') as OcrPlateResult['confidence'];

  const normalizedPlate = normalizePlateText(parsed.plateNumber || '');

  return {
    plateDetected: Boolean(parsed.plateDetected && normalizedPlate.length >= 4),
    plateNumber: normalizedPlate,
    confidence: normalizedPlate.length >= 4 ? validConfidence : 'unreadable',
    qualityIssues: parsed.qualityIssues || 'Image analyzed.',
    notes:
      parsed.notes ||
      (normalizedPlate
        ? 'Please verify every character against your uploaded photograph before confirming.'
        : 'No readable registration plate found. Please enter the vehicle number manually if visible.'),
  };
}

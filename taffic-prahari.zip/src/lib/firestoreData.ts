import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import { db } from './firebase';
import { handleFirestoreError, OperationType } from './firestoreError';
import type {
  AdminActivityLogDoc,
  ChallanRecordDoc,
  ComplaintStatus,
  OcrConfidence,
  RegisteredVehicleDoc,
  ReportEvidenceDoc,
  ReportStatusHistoryDoc,
  TrafficReportDoc,
  VehicleReportSummaryDoc,
  VehicleReportSummaryItem,
  ViolationCategory,
} from '../types/domain';

export function normalizePlateNumber(plate: string): string {
  return plate.toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 20);
}

export function generateComplaintCode(): string {
  const year = new Date().getFullYear();
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let suffix = '';
  for (let i = 0; i < 6; i++) {
    suffix += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `TP-${year}-${suffix}`;
}

export interface UploadedEvidenceInput {
  fileId: string;
  fileName: string;
  mimeType: 'image/jpeg' | 'image/png' | 'image/webp';
  fileSize: number;
  evidenceUrl: string;
}

export interface CreateReportInput {
  reporterId: string;
  violationType: ViolationCategory;
  incidentDate: string;
  incidentTime: string;
  locationText: string;
  latitude: number;
  longitude: number;
  vehicleRegNumber: string;
  ocrExtractedPlate: string;
  ocrConfidence: OcrConfidence;
  ocrConfirmed: boolean;
  description: string;
  evidenceFiles: UploadedEvidenceInput[];
}

export async function createTrafficReport(
  input: CreateReportInput
): Promise<{ reportId: string; complaintCode: string }> {
  const reportId = `rpt_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const complaintCode = generateComplaintCode();
  const cleanPlate = normalizePlateNumber(input.vehicleRegNumber);
  const cleanOcrPlate = normalizePlateNumber(input.ocrExtractedPlate);

  const reportPath = `trafficReports/${reportId}`;
  try {
    await setDoc(doc(db, 'trafficReports', reportId), {
      id: reportId,
      complaintCode,
      reporterId: input.reporterId,
      violationType: input.violationType,
      incidentDate: input.incidentDate.slice(0, 20),
      incidentTime: input.incidentTime.slice(0, 20),
      locationText: input.locationText.trim().slice(0, 300),
      latitude: input.latitude,
      longitude: input.longitude,
      vehicleRegNumber: cleanPlate,
      ocrExtractedPlate: cleanOcrPlate,
      ocrConfidence: input.ocrConfidence,
      ocrConfirmed: input.ocrConfirmed,
      description: input.description.trim().slice(0, 2000),
      status: 'Submitted',
      adminRemarks: '',
      evidenceCount: input.evidenceFiles.length,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    for (let i = 0; i < input.evidenceFiles.length; i++) {
      const file = input.evidenceFiles[i];
      const evId = `ev_${Date.now()}_${i}_${Math.random().toString(36).slice(2, 6)}`;
      await setDoc(doc(db, 'trafficReports', reportId, 'evidence', evId), {
        id: evId,
        reportId,
        reporterId: input.reporterId,
        fileName: file.fileName.slice(0, 200),
        mimeType: file.mimeType,
        fileSize: file.fileSize,
        evidenceUrl: file.evidenceUrl.slice(0, 500),
        createdAt: serverTimestamp(),
      });
    }

    const histId = `hist_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    await setDoc(doc(db, 'trafficReports', reportId, 'statusHistory', histId), {
      id: histId,
      reportId,
      reporterId: input.reporterId,
      status: 'Submitted',
      remarks: 'Complaint registered by citizen with incident details and photographic evidence.',
      actorId: input.reporterId,
      actorRole: 'citizen',
      createdAt: serverTimestamp(),
    });

    return { reportId, complaintCode };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, reportPath);
  }
}

export async function fetchUserReports(uid: string): Promise<TrafficReportDoc[]> {
  try {
    const q = query(
      collection(db, 'trafficReports'),
      where('reporterId', '==', uid),
      orderBy('createdAt', 'desc')
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => d.data() as TrafficReportDoc);
  } catch (error) {
    // Fallback without composite index if needed
    try {
      const qSimple = query(
        collection(db, 'trafficReports'),
        where('reporterId', '==', uid)
      );
      const snap = await getDocs(qSimple);
      const rows = snap.docs.map((d) => d.data() as TrafficReportDoc);
      return rows.sort((a, b) => toMillis(b.createdAt) - toMillis(a.createdAt));
    } catch (innerErr) {
      handleFirestoreError(innerErr, OperationType.LIST, 'trafficReports');
    }
    throw error;
  }
}

export async function fetchReportDetails(reportId: string): Promise<{
  report: TrafficReportDoc | null;
  evidence: ReportEvidenceDoc[];
  history: ReportStatusHistoryDoc[];
}> {
  try {
    const reportSnap = await getDoc(doc(db, 'trafficReports', reportId));
    if (!reportSnap.exists()) {
      return { report: null, evidence: [], history: [] };
    }

    const evSnap = await getDocs(collection(db, 'trafficReports', reportId, 'evidence'));
    const histSnap = await getDocs(collection(db, 'trafficReports', reportId, 'statusHistory'));

    const evidence = evSnap.docs.map((d) => d.data() as ReportEvidenceDoc);
    const history = histSnap.docs
      .map((d) => d.data() as ReportStatusHistoryDoc)
      .sort((a, b) => toMillis(a.createdAt) - toMillis(b.createdAt));

    return {
      report: reportSnap.data() as TrafficReportDoc,
      evidence,
      history,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `trafficReports/${reportId}`);
  }
}

export async function fetchUserVehicles(uid: string): Promise<RegisteredVehicleDoc[]> {
  try {
    const q = query(collection(db, 'registeredVehicles'), where('userId', '==', uid));
    const snap = await getDocs(q);
    return snap.docs
      .map((d) => d.data() as RegisteredVehicleDoc)
      .sort((a, b) => toMillis(b.createdAt) - toMillis(a.createdAt));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'registeredVehicles');
  }
}

export async function registerUserVehicle(input: {
  uid: string;
  registrationNumber: string;
  vehicleType: RegisteredVehicleDoc['vehicleType'];
  label: string;
}): Promise<RegisteredVehicleDoc> {
  const plate = normalizePlateNumber(input.registrationNumber);
  if (plate.length < 4) {
    throw new Error('Registration number must contain at least 4 alphanumeric characters.');
  }
  const vehicleId = `${input.uid}_${plate}`;
  try {
    await setDoc(doc(db, 'registeredVehicles', vehicleId), {
      id: vehicleId,
      userId: input.uid,
      registrationNumber: plate,
      vehicleType: input.vehicleType,
      label: input.label.trim().slice(0, 60) || 'Personal Vehicle',
      ownershipVerified: false,
      verificationMethod: 'Pending Ownership Declaration',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    const created = await getDoc(doc(db, 'registeredVehicles', vehicleId));
    return created.data() as RegisteredVehicleDoc;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `registeredVehicles/${vehicleId}`);
  }
}

export async function verifyVehicleOwnership(
  vehicleId: string,
  method: string
): Promise<void> {
  try {
    await updateDoc(doc(db, 'registeredVehicles', vehicleId), {
      ownershipVerified: true,
      verificationMethod: method.slice(0, 80),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `registeredVehicles/${vehicleId}`);
  }
}

export async function removeUserVehicle(vehicleId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'registeredVehicles', vehicleId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `registeredVehicles/${vehicleId}`);
  }
}

export async function fetchVehicleSummaryIfVerified(
  plateNumber: string
): Promise<VehicleReportSummaryDoc | null> {
  const plate = normalizePlateNumber(plateNumber);
  if (plate.length < 4) return null;
  try {
    const snap = await getDoc(doc(db, 'vehicleReportSummaries', plate));
    return snap.exists() ? (snap.data() as VehicleReportSummaryDoc) : null;
  } catch (error) {
    // If no reports have been published for this plate yet or rule denies unverified access
    const msg = error instanceof Error ? error.message : String(error);
    if (msg.toLowerCase().includes('permission') || msg.toLowerCase().includes('insufficient')) {
      return null;
    }
    handleFirestoreError(error, OperationType.GET, `vehicleReportSummaries/${plate}`);
  }
}

export async function fetchUserChallanRecords(uid: string): Promise<ChallanRecordDoc[]> {
  try {
    const q = query(collection(db, 'challanRecords'), where('vehicleOwnerId', '==', uid));
    const snap = await getDocs(q);
    return snap.docs
      .map((d) => d.data() as ChallanRecordDoc)
      .sort((a, b) => toMillis(b.createdAt) - toMillis(a.createdAt));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'challanRecords');
  }
}

export async function saveDemonstrationChallans(
  uid: string,
  plateNumber: string,
  records: Array<{
    challanNumber: string;
    vehicleRegNumber: string;
    violationCategory: string;
    incidentDate: string;
    locationText: string;
    amountInr: number;
    paymentStatus: 'Pending' | 'Paid' | 'Disputed';
    sourceName: string;
    isDemonstration: boolean;
  }>
): Promise<void> {
  const plate = normalizePlateNumber(plateNumber);
  try {
    for (let i = 0; i < records.length; i++) {
      const rec = records[i];
      const challanId = `ch_${uid.slice(0, 12)}_${plate}_${i + 1}`;
      await setDoc(doc(db, 'challanRecords', challanId), {
        id: challanId,
        challanNumber: rec.challanNumber.slice(0, 40),
        vehicleOwnerId: uid,
        vehicleRegNumber: plate,
        violationCategory: rec.violationCategory.slice(0, 120),
        incidentDate: rec.incidentDate.slice(0, 30),
        locationText: rec.locationText.slice(0, 240),
        amountInr: rec.amountInr,
        paymentStatus: rec.paymentStatus,
        sourceName: rec.sourceName.slice(0, 160),
        isDemonstration: true,
        createdAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'challanRecords');
  }
}

// --- Admin Queries & Mutations ---

export async function fetchAllReportsAdmin(): Promise<TrafficReportDoc[]> {
  try {
    const snap = await getDocs(collection(db, 'trafficReports'));
    return snap.docs
      .map((d) => d.data() as TrafficReportDoc)
      .sort((a, b) => toMillis(b.createdAt) - toMillis(a.createdAt));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'trafficReports');
  }
}

export async function fetchAdminActivityLogs(): Promise<AdminActivityLogDoc[]> {
  try {
    const snap = await getDocs(collection(db, 'adminActivityLogs'));
    return snap.docs
      .map((d) => d.data() as AdminActivityLogDoc)
      .sort((a, b) => toMillis(b.createdAt) - toMillis(a.createdAt));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'adminActivityLogs');
  }
}

export async function updateReportStatusAdmin(input: {
  report: TrafficReportDoc;
  newStatus: ComplaintStatus;
  adminRemarks: string;
  adminUid: string;
  adminEmail: string;
}): Promise<void> {
  const { report, newStatus, adminRemarks, adminUid, adminEmail } = input;
  const cleanRemarks = adminRemarks.trim().slice(0, 1000);

  try {
    await updateDoc(doc(db, 'trafficReports', report.id), {
      status: newStatus,
      adminRemarks: cleanRemarks,
      updatedAt: serverTimestamp(),
    });

    const histId = `hist_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    await setDoc(doc(db, 'trafficReports', report.id, 'statusHistory', histId), {
      id: histId,
      reportId: report.id,
      reporterId: report.reporterId,
      status: newStatus,
      remarks: cleanRemarks || `Status updated to ${newStatus} by Traffic Administration.`,
      actorId: adminUid,
      actorRole: 'admin',
      createdAt: serverTimestamp(),
    });

    const logId = `log_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    await setDoc(doc(db, 'adminActivityLogs', logId), {
      id: logId,
      adminUid,
      adminEmail: adminEmail.slice(0, 160),
      actionType: 'STATUS_UPDATE',
      targetReportId: report.id,
      targetComplaintCode: report.complaintCode,
      previousStatus: report.status,
      newStatus,
      remarks: cleanRemarks || `Updated to ${newStatus}`,
      createdAt: serverTimestamp(),
    });

    // Sync anonymized summary to vehicleReportSummaries for verified vehicle owners (NO reporter PII)
    const plate = normalizePlateNumber(report.vehicleRegNumber);
    if (plate.length >= 4 && newStatus !== 'Rejected') {
      const summaryRef = doc(db, 'vehicleReportSummaries', plate);
      const existingSnap = await getDoc(summaryRef);
      const existingSummaries: VehicleReportSummaryItem[] = existingSnap.exists()
        ? ((existingSnap.data() as VehicleReportSummaryDoc).summaries || [])
        : [];

      const updatedItem: VehicleReportSummaryItem = {
        complaintCode: report.complaintCode,
        violationType: report.violationType,
        incidentDate: report.incidentDate,
        locationText: report.locationText,
        status: newStatus,
        updatedAtIso: new Date().toISOString(),
      };

      const filtered = existingSummaries.filter(
        (item) => item.complaintCode !== report.complaintCode
      );
      const nextSummaries = [updatedItem, ...filtered].slice(0, 50);

      await setDoc(summaryRef, {
        plateNumber: plate,
        totalReports: nextSummaries.length,
        summaries: nextSummaries,
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `trafficReports/${report.id}`);
  }
}

export function toMillis(ts: unknown): number {
  if (!ts) return 0;
  if (ts instanceof Date) return ts.getTime();
  if (typeof ts === 'object' && ts !== null && 'toMillis' in ts) {
    return (ts as { toMillis: () => number }).toMillis();
  }
  if (typeof ts === 'object' && ts !== null && 'seconds' in ts) {
    return Number((ts as { seconds: number }).seconds) * 1000;
  }
  return 0;
}

export function formatTimestamp(ts: unknown): string {
  const ms = toMillis(ts);
  if (!ms) return 'Just now';
  return new Date(ms).toLocaleString('en-IN', {
    dateStyle: 'medium',
    timeStyle: 'short',
  });
}

import { useCallback, useEffect, useState } from 'react';
import { LogOut, Menu, X } from 'lucide-react';
import { AdminPanelView } from './components/AdminPanelView';
import { AuthPortal } from './components/AuthPortal';
import { BrandLogo } from './components/BrandMark';
import { DashboardView, type AppSection } from './components/DashboardView';
import { ErrorBoundary } from './components/ErrorBoundary';
import { MyReportsView } from './components/MyReportsView';
import { MyVehiclesView } from './components/MyVehiclesView';
import { NearbyAssistanceView } from './components/NearbyAssistanceView';
import { ProfileView } from './components/ProfileView';
import { ReportViolationView } from './components/ReportViolationView';
import { AuthProvider, useAuth } from './context/AuthContext';
import { fetchUserReports, fetchUserVehicles } from './lib/firestoreData';
import type { RegisteredVehicleDoc, TrafficReportDoc } from './types/domain';

function PortalShell() {
  const {
    firebaseUser,
    userDoc,
    profileDoc,
    isAdmin,
    loading: authLoading,
    needsProfileCompletion,
    logout,
  } = useAuth();

  const [activeSection, setActiveSection] = useState<AppSection>('dashboard');
  const [selectedReportId, setSelectedReportId] = useState<string | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [reports, setReports] = useState<TrafficReportDoc[]>([]);
  const [vehicles, setVehicles] = useState<RegisteredVehicleDoc[]>([]);
  const [dataLoading, setDataLoading] = useState(false);
  const [dataError, setDataError] = useState<string | null>(null);

  const refreshCitizenData = useCallback(async () => {
    if (!firebaseUser) return;
    setDataLoading(true);
    setDataError(null);
    try {
      const [loadedReports, loadedVehicles] = await Promise.all([
        fetchUserReports(firebaseUser.uid),
        fetchUserVehicles(firebaseUser.uid),
      ]);
      setReports(loadedReports);
      setVehicles(loadedVehicles);
    } catch (err) {
      setDataError(
        err instanceof Error ? err.message : 'Unable to load dashboard records.'
      );
    } finally {
      setDataLoading(false);
    }
  }, [firebaseUser]);

  useEffect(() => {
    if (firebaseUser) {
      void refreshCitizenData();
    } else {
      setReports([]);
      setVehicles([]);
      setActiveSection('dashboard');
      setSelectedReportId(null);
    }
  }, [firebaseUser, refreshCitizenData]);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-[#F5F3EF] flex items-center justify-center p-6">
        <div className="text-sm font-mono text-[#24282C]">
          Initializing TAFFIC-PRAHARI portal...
        </div>
      </div>
    );
  }

  if (!firebaseUser) {
    return <AuthPortal />;
  }

  function navigateTo(section: AppSection) {
    setActiveSection(section);
    if (section !== 'my-reports') {
      setSelectedReportId(null);
    }
    setMobileMenuOpen(false);
  }

  function handleOpenReport(reportId: string) {
    setSelectedReportId(reportId);
    setActiveSection('my-reports');
    setMobileMenuOpen(false);
  }

  const displayName =
    profileDoc?.fullName ||
    userDoc?.fullName ||
    firebaseUser.displayName ||
    firebaseUser.email?.split('@')[0] ||
    'Citizen';

  const initials = displayName
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() || '')
    .join('');

  const centerNavItems: Array<{ id: AppSection; label: string }> = [
    { id: 'dashboard', label: 'Overview' },
    { id: 'my-reports', label: 'My Reports' },
    { id: 'vehicles', label: 'My Vehicles' },
    { id: 'nearby', label: 'Assistance' },
    ...(isAdmin ? [{ id: 'admin' as AppSection, label: 'Admin' }] : []),
  ];

  return (
    <div className="min-h-screen bg-[#F5F3EF] text-[#171A1D] flex flex-col">
      {/* Premium Dark Charcoal Navigation Bar */}
      <header className="bg-[#171A1D] text-white border-b border-[#24282C] sticky top-0 z-30">
        <div className="max-w-[1320px] mx-auto px-6 h-16 flex items-center justify-between gap-6">
          {/* Left: Brand Identity + Minimal Road Logo */}
          <button
            type="button"
            onClick={() => navigateTo('dashboard')}
            className="flex items-center gap-3 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <BrandLogo className="w-8 h-8" />
            <span className="font-display text-base font-bold tracking-tight text-white">
              TAFFIC-PRAHARI
            </span>
          </button>

          {/* Centre: Clean Single-Line Navigation Links */}
          <nav
            aria-label="Primary navigation"
            className="hidden md:flex items-center gap-7 text-sm font-medium"
          >
            {centerNavItems.map((item) => {
              const active = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => navigateTo(item.id)}
                  className={`py-5 border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? 'border-[#F15A24] text-white'
                      : 'border-transparent text-[#92969A] hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Right: Profile Avatar + Name + Traffic Orange Primary CTA */}
          <div className="flex items-center gap-4 shrink-0">
            <button
              type="button"
              onClick={() => navigateTo('profile')}
              className="hidden sm:inline-flex items-center gap-2.5 text-left group cursor-pointer"
              title="Open Profile & Account"
            >
              <span
                className={`w-8 h-8 rounded-full bg-[#24282C] border flex items-center justify-center text-xs font-mono font-semibold text-white transition-colors ${
                  activeSection === 'profile'
                    ? 'border-[#F15A24]'
                    : 'border-[#3A4046] group-hover:border-[#92969A]'
                }`}
              >
                {initials || 'U'}
              </span>
              <span className="hidden lg:inline text-xs font-medium text-[#F5F3EF] max-w-[130px] truncate">
                {displayName}
              </span>
            </button>

            <button
              type="button"
              onClick={() => navigateTo('report')}
              className="hidden sm:inline-flex items-center px-4 py-2 bg-[#F15A24] hover:bg-[#D94A17] text-white text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Report Violation
            </button>

            <button
              type="button"
              onClick={() => setMobileMenuOpen((prev) => !prev)}
              aria-label="Toggle navigation menu"
              className="md:hidden p-2 border border-[#3A4046] bg-[#24282C] text-white"
            >
              {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Responsive Mobile Drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-[#24282C] bg-[#171A1D] px-6 py-4 space-y-2">
            {centerNavItems.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => navigateTo(item.id)}
                className={`block w-full text-left py-2 text-sm font-medium ${
                  activeSection === item.id ? 'text-[#F15A24]' : 'text-[#F5F3EF]'
                }`}
              >
                {item.label}
              </button>
            ))}
            <button
              type="button"
              onClick={() => navigateTo('profile')}
              className={`block w-full text-left py-2 text-sm font-medium ${
                activeSection === 'profile' ? 'text-[#F15A24]' : 'text-[#F5F3EF]'
              }`}
            >
              Profile ({displayName})
            </button>
            <button
              type="button"
              onClick={() => navigateTo('report')}
              className="block w-full text-left py-2 text-sm font-semibold text-[#F15A24]"
            >
              Report Violation
            </button>
            <button
              type="button"
              onClick={() => void logout()}
              className="block w-full text-left py-2 text-sm text-[#92969A] border-t border-[#24282C] mt-2 pt-3"
            >
              Sign Out
            </button>
          </div>
        )}
      </header>

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-[1320px] w-full mx-auto px-6 py-8">
        {needsProfileCompletion ? (
          <ProfileView isOnboarding />
        ) : activeSection === 'dashboard' ? (
          <DashboardView
            reports={reports}
            vehicles={vehicles}
            loading={dataLoading}
            error={dataError}
            onNavigate={navigateTo}
            onOpenReport={handleOpenReport}
          />
        ) : activeSection === 'report' ? (
          <ReportViolationView
            onSubmitted={async (reportId) => {
              await refreshCitizenData();
              setSelectedReportId(reportId);
              setActiveSection('my-reports');
            }}
            onCancel={() => navigateTo('dashboard')}
          />
        ) : activeSection === 'my-reports' ? (
          <MyReportsView
            reports={reports}
            loading={dataLoading}
            selectedReportId={selectedReportId}
            onSelectReport={setSelectedReportId}
          />
        ) : activeSection === 'vehicles' ? (
          <MyVehiclesView
            vehicles={vehicles}
            loading={dataLoading}
            onRefreshVehicles={refreshCitizenData}
          />
        ) : activeSection === 'nearby' ? (
          <NearbyAssistanceView />
        ) : activeSection === 'admin' ? (
          <AdminPanelView />
        ) : (
          <div className="space-y-6">
            <ProfileView />
            <div className="max-w-2xl mx-auto flex justify-end">
              <button
                type="button"
                onClick={() => void logout()}
                className="inline-flex items-center gap-2 px-4 py-2 border border-[#D4D0C8] bg-white hover:bg-[#FEE2E2] hover:text-[#991B1B] text-xs font-medium text-[#24282C] transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out of Session</span>
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Quiet Civic Footer */}
      <footer className="border-t border-[#E2DFD7] bg-white py-5">
        <div className="max-w-[1320px] mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#6B7280]">
          <span>TAFFIC-PRAHARI · Report Responsibly. Make Roads Safer.</span>
          <div className="flex items-center gap-5">
            <button
              type="button"
              onClick={() => navigateTo('profile')}
              className="hover:text-[#171A1D] underline cursor-pointer"
            >
              Profile & Account
            </button>
            <button
              type="button"
              onClick={() => void logout()}
              className="hover:text-[#171A1D] underline cursor-pointer"
            >
              Sign Out
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <PortalShell />
      </AuthProvider>
    </ErrorBoundary>
  );
}

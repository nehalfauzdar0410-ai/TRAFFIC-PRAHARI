export const VIOLATION_CATEGORIES = [
  'Driving without helmet',
  'Driving without seatbelt',
  'Signal jumping',
  'Wrong-side driving',
  'Illegal parking',
  'Over-speeding',
  'Using a mobile phone while driving',
  'Triple riding',
  'Other violations',
] as const;

export type ViolationCategory = (typeof VIOLATION_CATEGORIES)[number];

export const COMPLAINT_STATUSES = [
  'Submitted',
  'Under Review',
  'Verified',
  'Action Taken',
  'Resolved',
  'Rejected',
] as const;

export type ComplaintStatus = (typeof COMPLAINT_STATUSES)[number];

export type UserRole = 'citizen' | 'admin';

export type OcrConfidence = 'high' | 'medium' | 'low' | 'unreadable' | 'manual' | 'none';

export interface UserDoc {
  uid: string;
  fullName: string;
  role: UserRole;
  createdAt: unknown;
  updatedAt: unknown;
}

export interface UserProfileDoc {
  uid: string;
  fullName: string;
  email: string;
  mobileNumber: string;
  primaryVehicleReg: string;
  createdAt: unknown;
  updatedAt: unknown;
}

export interface RegisteredVehicleDoc {
  id: string;
  userId: string;
  registrationNumber: string;
  vehicleType: 'Two-Wheeler' | 'Four-Wheeler' | 'Commercial' | 'Heavy Vehicle' | 'Other';
  label: string;
  ownershipVerified: boolean;
  verificationMethod: string;
  createdAt: unknown;
  updatedAt: unknown;
}

export interface TrafficReportDoc {
  id: string;
  complaintCode: string;
  reporterId: string;
  violationType: ViolationCategory;
  incidentDate: string;
  incidentTime: string;
  locationText: string;
  latitude: number;
  longitude: number;
  vehicleRegNumber: string;
  ocrExtractedPlate: string;
  ocrConfidence: OcrConfidence;
  ocrConfirmed: boolean;
  description: string;
  status: ComplaintStatus;
  adminRemarks: string;
  evidenceCount: number;
  createdAt: unknown;
  updatedAt: unknown;
}

export interface ReportEvidenceDoc {
  id: string;
  reportId: string;
  reporterId: string;
  fileName: string;
  mimeType: 'image/jpeg' | 'image/png' | 'image/webp';
  fileSize: number;
  evidenceUrl: string;
  createdAt: unknown;
}

export interface ReportStatusHistoryDoc {
  id: string;
  reportId: string;
  reporterId: string;
  status: ComplaintStatus;
  remarks: string;
  actorId: string;
  actorRole: 'citizen' | 'admin';
  createdAt: unknown;
}

export interface ChallanRecordDoc {
  id: string;
  challanNumber: string;
  vehicleOwnerId: string;
  vehicleRegNumber: string;
  violationCategory: string;
  incidentDate: string;
  locationText: string;
  amountInr: number;
  paymentStatus: 'Pending' | 'Paid' | 'Disputed';
  sourceName: string;
  isDemonstration: boolean;
  createdAt: unknown;
}

export interface AdminUserDoc {
  uid: string;
  email: string;
  displayName: string;
  badgeId: string;
  active: boolean;
  createdAt: unknown;
}

export interface AdminActivityLogDoc {
  id: string;
  adminUid: string;
  adminEmail: string;
  actionType: string;
  targetReportId: string;
  targetComplaintCode: string;
  previousStatus: string;
  newStatus: string;
  remarks: string;
  createdAt: unknown;
}

export interface VehicleReportSummaryItem {
  complaintCode: string;
  violationType: string;
  incidentDate: string;
  locationText: string;
  status: ComplaintStatus;
  updatedAtIso: string;
}

export interface VehicleReportSummaryDoc {
  plateNumber: string;
  totalReports: number;
  summaries: VehicleReportSummaryItem[];
  updatedAt: unknown;
}

export const BOOTSTRAPPED_ADMIN_EMAIL = '2000014064@karnavatiuniversity.edu.in';
